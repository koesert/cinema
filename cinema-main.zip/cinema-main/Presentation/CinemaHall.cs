public class CinemaHall
{
    public int HallId { get; set; }
    public string HallName { get; set; }
    public List<Seat> Seats { get; set; }
}
public class Seat
{
    public int SeatNumber { get; set; }
    public bool IsReserved { get; set; }
}